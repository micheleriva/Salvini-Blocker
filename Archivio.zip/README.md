<h1 align="center"> 🐷 Salvini-Blocker 🐷 </h1>
<p align="center"> Like Ad-Block, but for Matteo Salvini  </p>

<img src="/docs/Salvini-Block.png" align="center" />